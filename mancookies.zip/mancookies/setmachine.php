<!DOCTYPE html>
<?php
$cookie_name = "Moodle_iqraa_auth";
$cookie_value = "test validation key";
setcookie($cookie_name, $cookie_value, time() + (86400 * 10 * 30), "/"); // 86400 = 1 day
