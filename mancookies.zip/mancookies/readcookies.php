<?php


$cookie_name = "Moodle_iqraa_auth";
$fromcookies="";
if(!isset($_COOKIE[$cookie_name])) {
    echo "Cookie '" . $cookie_name . "' is set!<br>";
    echo "Value is: " . $fromcookies;
} else {
    $fromcookies=$_COOKIE[$cookie_name];
    echo "Cookie '" . $cookie_name . "' is set!<br>";
    echo "Value is: " . $fromcookies;
}
echo '--' . $USER->profile['authcookies'] . '--' . '--' . $USER->id . '--' ;