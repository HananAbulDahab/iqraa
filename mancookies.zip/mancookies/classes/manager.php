<?php
/**
 * @package     local_mancookies
 * @author  validationkey    iqraa
 * @license     http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace local_mancookies;

use dml_exception;
use stdClass;

class manager {

    /** Insert the data into our database table.
     * @param string $machine_text
     * @param string $machine_type
     * @return bool true if successful
     */

    /** Gets all machines
     * @return array of machines
     */
    public function get_all_mancookies(): array {
        global $DB;
        return $DB->get_records('user');
    }

    /** Mark that a machine was read by this user.
     * @param int $machine_id the message to mark as read
     * @param int $userid the user that we are marking message read
     * @return bool true if successful
     */
    /** Get a single machine from its id.
     * @param int $machineid the machine we're trying to get.
     * @return object|false machine data or false if not found.
     */
    public function get_mancookies(int $machineid)
    {
        global $DB;
        return $DB->get_record('user', ['id' => $userid]);
    }

    /** Update details for a single machine.
     * @param int $machineid the machine we're trying to get.
     * @param string $machine_text the new text for the machine.
     * @param string $machine_type the new type for the machine.
     * @return bool machine data or false if not found.
     */
//    public function update_mancookies(int $userid, string $validation_key): bool
//    {
//        global $DB;
//        $object = new stdClass();
//        $object->userid = $userid;
//        $object->fieldid = 4;
//        $object->data = $validation_key;
//        return $DB->update_record('user_info_data', $object);
//    }
//    public function update_validationkey(): bool
//    {
//        return true;
//    }
    /** Update the type for an array of machines.
     * @return bool machine data or false if not found.
     */
    
}    