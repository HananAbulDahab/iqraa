# Local machine

This is a machine plugin for moodle. It will collect machine info and allows admins to create them.



## Functionality
- Form for admins to add new machine
