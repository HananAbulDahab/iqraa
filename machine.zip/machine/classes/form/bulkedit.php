<?php


/**
 * @package     local_machine
 * @author      iqraa
 * @license     http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace local_machine\form;
use local_machine\manager;
use moodleform;

require_once("$CFG->libdir/formslib.php");

class bulkedit extends moodleform {
    public function definition() {
        $mform = $this->_form; // Don't forget the underscore!

        // Display the list of messages with a checkbox.
        $manager = new manager();
        $machines = $manager->get_all_machines();

        $machinegroup = [];
        foreach ($machines as $machine) {
            $machinegroup[] = $mform->createElement('advcheckbox', 'machineid' . $machine->id, $machine->machinetext);
        }
        $mform->addGroup($machinegroup, 'machines', get_string('choose_machines', 'local_machine'), '<br>');

        $mform->addElement('static', 'todo', get_string('whattodo', 'local_message'));

        $choices = array();
        $choices['0'] = \core\output\notification::NOTIFY_WARNING;
        $choices['1'] = \core\output\notification::NOTIFY_SUCCESS;
        
        $mform->addElement('select', 'machinetype', get_string('machine_type', 'local_machine'), $choices);
        $mform->setDefault('machine', '1');

        $mform->addElement('advcheckbox', 'deleteall', get_string('delete_all_selected', 'local_machine'), get_string('yes'));

        $this->add_action_buttons();
    }
    //Custom validation should be added here
    function validation($data, $files) {
        return array();
    }
}
