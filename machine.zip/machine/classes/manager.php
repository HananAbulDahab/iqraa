<?php


/**
 * @package     local_machine
 * @author      iqraa
 * @license     http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace local_machine;

use dml_exception;
use stdClass;

class manager {

    /** Insert the data into our database table.
     * @param string $machine_text
     * @param string $machine_type
     * @return bool true if successful
     */
    public function create_machine(string $machine_text, string $machine_type): bool
    {
        global $DB;
        $record_to_insert = new stdClass();
        $record_to_insert->machinetext = $machine_text;
        $record_to_insert->machinetype = $machine_type;
        try {
            return $DB->insert_record('local_machine', $record_to_insert, false);
        } catch (dml_exception $e) {
            return false;
        }
    }

    /** Gets all machines >>>
     * @param int $userid the user that we are getting messages for
     * @return array of messages
     */
//    public function get_machines(int $userid): array
//    {
//        global $DB;
//        $sql = "SELECT lm.id, lm.messagetext, lm.messagetype 
//            FROM {local_message} lm 
//            LEFT OUTER JOIN {local_message_read} lmr ON lm.id = lmr.messageid AND lmr.userid = :userid 
//            WHERE lmr.userid IS NULL";
//        $params = [
//            'userid' => $userid,
//        ];
//        try {
//            return $DB->get_records_sql($sql, $params);
//        } catch (dml_exception $e) {
//            // Log error here.
//            return [];
//        }
//    }

    /** Gets all machines
     * @return array of machines
     */
    public function get_all_machines(): array {
        global $DB;
        return $DB->get_records('local_machine');
    }

    /** Mark that a machine was read by this user.
     * @param int $machine_id the message to mark as read
     * @param int $userid the user that we are marking message read
     * @return bool true if successful
     */
    //public function mark_message_read(int $message_id, int $userid): bool
    //{
    //    global $DB;
    //    $read_record = new stdClass();
    //    $read_record->messageid = $message_id;
    //    $read_record->userid = $userid;
    //    $read_record->timeread = time();
    //    try {
    //        return $DB->insert_record('local_message_read', $read_record, false);
    //    } catch (dml_exception $e) {
    //        return false;
    //    }
    // }

    /** Get a single machine from its id.
     * @param int $machineid the machine we're trying to get.
     * @return object|false machine data or false if not found.
     */
    public function get_machine(int $machineid)
    {
        global $DB;
        return $DB->get_record('local_machine', ['id' => $machineid]);
    }

    /** Update details for a single machine.
     * @param int $machineid the machine we're trying to get.
     * @param string $machine_text the new text for the machine.
     * @param string $machine_type the new type for the machine.
     * @return bool machine data or false if not found.
     */
    public function update_machine(int $machineid, string $machine_text, string $machine_type): bool
    {
        global $DB;
        $object = new stdClass();
        $object->id = $machineid;
        $object->machinetext = $machine_text;
        $object->machinetype = $machine_type;
        return $DB->update_record('local_machine', $object);
    }

    /** Update the type for an array of machines.
     * @return bool machine data or false if not found.
     */
    public function update_machines(array $machineids, $type): bool
    {
        global $DB;
        list($ids, $params) = $DB->get_in_or_equal($machineids);
        return $DB->set_field_select('local_machine', 'machinetype', $type, "id $ids", $params);
    }

    /** Delete a machine and all the read history.
     * @param $machineid
     * @return bool
     * @throws \dml_transaction_exception
     * @throws dml_exception
     */
    public function delete_machine($machineid)
    {
        global $DB;
        $transaction = $DB->start_delegated_transaction();
        $deletedMachine = $DB->delete_records('local_machine', ['id' => $machineid]);
        //$deletedRead = $DB->delete_records('local_message_read', ['messageid' => $messageid]);
        if ($deletedMachine ) {
            $DB->commit_delegated_transaction($transaction);
        }
        return true;
    }

    /** Delete all machines by id.
     * @param $machineids
     * @return bool
     */
    public function delete_machines($machineids)
    {
        global $DB;
        $transaction = $DB->start_delegated_transaction();
        list($ids, $params) = $DB->get_in_or_equal($machineids);
        $deletedMachines = $DB->delete_records_select('local_machine', "id $ids", $params);
        //$deletedReads = $DB->delete_records_select('local_machine_read', "machineid $ids", $params);
        if ($deletedMachines ) {
            $DB->commit_delegated_transaction($transaction);
        }
        return true;
    }
}
