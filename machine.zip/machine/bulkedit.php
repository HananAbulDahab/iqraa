<?php

/**
 * @package     local_machine
 * @author      iqraa
 * @license     http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

use local_machine\form\bulkedit;
use local_machine\manager;

require_once(__DIR__ . '/../../config.php');

require_login();
$context = context_system::instance();
require_capability('local/machine:managemachines', $context);

$PAGE->set_url(new moodle_url('/local/machine/bulkedit.php'));
$PAGE->set_context(\context_system::instance());
$PAGE->set_title(get_string('bulk_edit', 'local_machine'));
$PAGE->set_heading(get_string('bulk_edit_machines', 'local_machine'));

$machineid = optional_param('machineid', null, PARAM_INT);

// We want to display our form.
$mform = new bulkedit();
$manager = new manager();

if ($mform->is_cancelled()) {
    // Go back to manage.php page
    redirect($CFG->wwwroot . '/local/machine/manage.php', get_string('cancelled_form', 'local_machine'));
} else if ($fromform = $mform->get_data()) {
    $machines = $fromform->machines;
    $machineids = [];
    foreach ($machines as $key => $enabled) {
        if ($enabled == true) {
            $machineids[] = substr($key, 9);
        }
    }

    if ($machineids) {
        if ($fromform->deleteall == true) {
            $manager->delete_machines($machineids);
        } else {
            $manager->update_machines($machineids, $fromform->machinetype);
        }
    }

    redirect($CFG->wwwroot . '/local/machine/manage.php', get_string('bulk_edit_successful', 'local_machine'));
}

echo $OUTPUT->header();
$mform->display();
echo $OUTPUT->footer();
