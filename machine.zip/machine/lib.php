<?php

/**
 * @package     local_message
 * @author      iqraa
 * @license     http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
//use local_machine\manager;

//function local_machine_before_footer() {
//    global $USER;

//    if (!get_config('local_machine', 'enabled')) {
//        return;
//    }

//    $manager = new manager();
//    $machines = $manager->get_messages($USER->id);

//    foreach ($machines as $machine) {
//        $type = \core\output\notification::NOTIFY_INFO;
//        if ($machine->machinetype === '0') {
//            $type = \core\output\notification::NOTIFY_WARNING;
//        }
//       $machine->mark_message_read($machine->id, $USER->id);
//    }
//}
