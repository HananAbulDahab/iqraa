<?php

/**
 * local_machine external file
 *
 * @package    component
 * @category   external
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

use local_machine\manager;
require_once($CFG->libdir . "/externallib.php");

class local_machine_external extends external_api  {
    /**
     * Returns description of method parameters
     * @return external_function_parameters
     */
    public static function delete_machine_parameters() {
        return new external_function_parameters(
            ['machineid' => new external_value(PARAM_INT, 'id of machine')],
        );
    }

    /**
     * The function itself
     * @return string welcome message
     */
    public static function delete_machine($machineid): string {
        $params = self::validate_parameters(self::delete_machine_parameters(), array('machineid'=>$machineid));

        require_capability('local/message:managemachines', context_system::instance());

        $manager = new manager();
        return $manager->delete_machine($machineid);
    }

    /**
     * Returns description of method result value
     * @return external_description
     */
    public static function delete_machine_returns() {
        return new external_value(PARAM_BOOL, 'True if the machine was successfully deleted.');
    }
}
