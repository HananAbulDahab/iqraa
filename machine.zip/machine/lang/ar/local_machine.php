<?php

/**
 * Strings for component 'local_machine', language 'ar'
 *
 * @package   local_machine
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

$string['pluginname'] = 'Broadcast machines';
$string['enter_machine'] = 'Please enter a machine';
$string['manage'] = 'Manage broadcast machines';
$string['setting_enable'] = 'Enable';
$string['setting_enable_desc'] = 'Disable to stop any machines from this plugin being displayed';
$string['machine_type'] = 'machine type';
$string['machine_text'] = 'machine text';
$string['machine:managemachines'] = 'Manage machines';
$string['cancelled_form'] = 'You cancelled the machine form';
$string['updated_form'] = 'You updated a machine with title ';
$string['created_form'] = 'You created a machine with title ';
$string['manage_machines'] = 'Manage machines';
$string['delete_machine'] = 'Delete machine';
$string['delete_machine_confirm'] = 'Are you sure you want to delete machine?';
$string['whattodo'] = 'What do you want to do with your selected machines?';
$string['choose_machines'] = 'Choose your machines';
$string['delete_all_selected'] = 'Delete all selected?';
$string['bulk_edit'] = 'Bulk Edit';
$string['bulk_edit_machines'] = 'Bulk edit your machines';
$string['bulk_edit_successful'] = 'Bulk edit successful!';


