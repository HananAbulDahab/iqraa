<?php

/**
 * @package     local_machine
 * @author      iqraa
 * @license     http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

require_once(__DIR__ . '/../../config.php');

global $DB;

require_login();
$context = context_system::instance();
require_capability('local/machine:managemachines', $context);

$PAGE->set_url(new moodle_url('/local/machine/manage.php'));
$PAGE->set_context(\context_system::instance());
$PAGE->set_title(get_string('manage_machines', 'local_machine'));
$PAGE->set_heading(get_string('manage_machines', 'local_machine'));
$PAGE->requires->js_call_amd('local_machine/confirm');
$PAGE->requires->css('/local/machine/styles.css');

$machines = $DB->get_records('local_machine', null, 'id');

echo $OUTPUT->header();
$templatecontext = (object)[
    'machines' => array_values($machines),
    'editurl' => new moodle_url('/local/machine/edit.php'),
    'bulkediturl' => new moodle_url('/local/machine/bulkedit.php'),
];

echo $OUTPUT->render_from_template('local_machine/manage', $templatecontext);

echo $OUTPUT->footer();
