
/**
 * Show a delete machine modal instead of doing it on a separate page.
 *
 * @module     local_machine
 */
define(['jquery', 'core/modal_factory', 'core/str', 'core/modal_events', 'core/ajax', 'core/notification'], function($, ModalFactory, String, ModalEvents, Ajax, Notification) {
    var trigger = $('.local_machine_delete_button');
    ModalFactory.create({
        type: ModalFactory.types.SAVE_CANCEL,
        title: String.get_string('delete_machine', 'local_machine'),
        body: String.get_string('delete_machine_confirm', 'local_machine'),
        preShowCallback: function(triggerElement, modal) {
            // Do something before we show the delete modal.
            triggerElement = $(triggerElement);

            let classString = triggerElement[0].classList[0]; // local_machineid13
            let machineid = classString.substr(classString.lastIndexOf('local_machineid') + 'local_machineid'.length);
            // Set the machine id in this modal.
            modal.params = {'machineid': machineid};
            modal.setSaveButtonText(String.get_string('delete_machine', 'local_machine'));
        },
        large: true,
    }, trigger)
        .done(function(modal) {
            // Do what you want with your new modal.
            modal.getRoot().on(ModalEvents.save, function(e) {
                // Stop the default save button behaviour which is to close the modal.
                e.preventDefault();

                let footer = Y.one('.modal-footer');
                footer.setContent('Deleting...');
                let spinner = M.util.add_spinner(Y, footer);
                spinner.show();
                let request = {
                    methodname: 'local_machine_delete_machine',
                    args: modal.params,
                };
                Ajax.call([request])[0].done(function(data) {
                    if (data === true) {
                        // Redirect to manage page.
                        window.location.reload();
                    } else {
                        Notification.addNotification({
                            message: String.get_string('delete_machine_failed', 'local_machine'),
                            type: 'error',
                        });
                    }
                }).fail(Notification.exception);
            });
        });

});
