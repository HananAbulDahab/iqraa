<?php

if ($hassiteconfig) { // needs this condition or there is error on login page

    $ADMIN->add('localplugins', new admin_category('local_machine_category', get_string('pluginname', 'local_machine')));

    $settings = new admin_settingpage('local_machine', get_string('pluginname', 'local_machine'));
    $ADMIN->add('local_machine_category', $settings);

    $settings->add(new admin_setting_configcheckbox('local_machine/enabled',
        get_string('setting_enable', 'local_machine'), get_string('setting_enable_desc', 'local_machine'), '1'));

    $ADMIN->add('local_machine_category', new admin_externalpage('local_machine_manage', get_string('manage', 'local_machine'),
        $CFG->wwwroot . '/local/machine/manage.php'));
}
