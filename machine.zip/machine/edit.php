<?php

/**
 * @package     local_machine
 * @author      iqraa
 * @license     http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

use local_machine\form\edit;
use local_machine\manager;

require_once(__DIR__ . '/../../config.php');

require_login();
$context = context_system::instance();
require_capability('local/machine:managemachines', $context);

$PAGE->set_url(new moodle_url('/local/machine/edit.php'));
$PAGE->set_context(\context_system::instance());
$PAGE->set_title('Edit');

$machineid = optional_param('machineid', null, PARAM_INT);

// We want to display our form.
$mform = new edit();

if ($mform->is_cancelled()) {
    // Go back to manage.php page
    redirect($CFG->wwwroot . '/local/machine/manage.php', get_string('cancelled_form', 'local_machine'));

} else if ($fromform = $mform->get_data()) {
    $manager = new manager();

    if ($fromform->id) {
        // We are updating an existing machine.
        $manager->update_machine($fromform->id, $fromform->machinetext, $fromform->machinetype);
        redirect($CFG->wwwroot . '/local/machine/manage.php', get_string('updated_form', 'local_machine') . $fromform->machinetext);
    }

    $manager->create_machine($fromform->machinetext, $fromform->machinetype);

    // Go back to manage.php page
    redirect($CFG->wwwroot . '/local/machine/manage.php', get_string('created_form', 'local_machine') . $fromform->machinetext);
}

if ($machineid) {
    // Add extra data to the form.
    global $DB;
    $manager = new manager();
    $machine = $manager->get_machine($machineid);
    if (!$machine) {
        throw new invalid_parameter_exception('machine not found');
    }
    $mform->set_data($machine);
}

echo $OUTPUT->header();
$mform->display();
echo $OUTPUT->footer();
