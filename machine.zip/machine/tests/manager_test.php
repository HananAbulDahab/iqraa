<?php

/**
 * Unit tests for local_machine
 *
 * @package    local_machine
 * @category   phpunit
 */

defined('MOODLE_INTERNAL') || die();

use local_machine\manager;
global $CFG;
require_once($CFG->dirroot . '/local/machine/lib.php');

class local_machine_manager_test extends advanced_testcase
{
    /**
     * Test that we can create a machine.
     */
    public function test_create_machine() {
        $this->resetAfterTest();
        $this->setUser(2);
        $manager = new manager();
        $machines = $manager->get_machines(2);
        $this->assertEmpty($machines);

        $type = \core\output\notification::NOTIFY_SUCCESS;
        $result = $manager->create_machine('Test machine', $type);

        $this->assertTrue($result);
        $machines = $manager->get_machines(2);
        $this->assertNotEmpty($machines);

        $this->assertCount(1, $machines);
        $machine = array_pop($machines);

        $this->assertEquals('Test machine', $machine->machinetext);
        $this->assertEquals($type, $machine->machinetype);
    }

    /**
     * Test that we get the correct machines.
     */
    public function test_get_machines() {

        global $DB;
        $this->resetAfterTest();
        $this->setUser(2);
        $manager = new manager();

        $type = \core\output\notification::NOTIFY_SUCCESS;
        $manager->create_machine('Test machine1', $type);
        $manager->create_machine('Test machine2', $type);
        $manager->create_machine('Test machine3', $type);

        $machines = $DB->get_records('local_machine');

        foreach ($machines as $id => $machine) {
            $manager->mark_machine_read($id, 1);
        }

        $machinesAdmin = $manager->get_machines(2);
        $this->assertCount(3, $machinesAdmin);

        foreach ($machines as $id => $machine) {
            $manager->mark_machine_read($id, 2);
        }

        $machinesAdmin = $manager->get_machines(2);
        $this->assertCount(0, $machinesAdmin);
    }
}
