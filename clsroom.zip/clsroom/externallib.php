<?php

/**
 * local_clsroom external file
 *
 * @package    component
 * @category   external
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

use local_clsroom\manager;
require_once($CFG->libdir . "/externallib.php");

class local_clsroom_external extends external_api  {
    /**
     * Returns description of method parameters
     * @return external_function_parameters
     */
    public static function delete_clsroom_parameters() {
        return new external_function_parameters(
            ['clsroomid' => new external_value(PARAM_INT, 'id of clsroom')],
        );
    }

    /**
     * The function itself
     * @return string welcome message
     */
    public static function delete_clsroom($clsroomid): string {
        $params = self::validate_parameters(self::delete_clsroom_parameters(), array('clsroomid'=>$clsroomid));

        require_capability('local/message:manageclsrooms', context_system::instance());

        $manager = new manager();
        return $manager->delete_clsroom($clsroomid);
    }

    /**
     * Returns description of method result value
     * @return external_description
     */
    public static function delete_clsroom_returns() {
        return new external_value(PARAM_BOOL, 'True if the clsroom was successfully deleted.');
    }
}
