
/**
 * Show a delete clsroom modal instead of doing it on a separate page.
 *
 * @module     local_clsroom
 */
define(['jquery', 'core/modal_factory', 'core/str', 'core/modal_events', 'core/ajax', 'core/notification'], function($, ModalFactory, String, ModalEvents, Ajax, Notification) {
    var trigger = $('.local_clsroom_delete_button');
    ModalFactory.create({
        type: ModalFactory.types.SAVE_CANCEL,
        title: String.get_string('delete_clsroom', 'local_clsroom'),
        body: String.get_string('delete_clsroom_confirm', 'local_clsroom'),
        preShowCallback: function(triggerElement, modal) {
            // Do something before we show the delete modal.
            triggerElement = $(triggerElement);

            let classString = triggerElement[0].classList[0]; // local_clsroomid13
            let clsroomid = classString.substr(classString.lastIndexOf('local_clsroomid') + 'local_clsroomid'.length);
            // Set the clsroom id in this modal.
            modal.params = {'clsroomid': clsroomid};
            modal.setSaveButtonText(String.get_string('delete_clsroom', 'local_clsroom'));
        },
        large: true,
    }, trigger)
        .done(function(modal) {
            // Do what you want with your new modal.
            modal.getRoot().on(ModalEvents.save, function(e) {
                // Stop the default save button behaviour which is to close the modal.
                e.preventDefault();

                let footer = Y.one('.modal-footer');
                footer.setContent('Deleting...');
                let spinner = M.util.add_spinner(Y, footer);
                spinner.show();
                let request = {
                    methodname: 'local_clsroom_delete_clsroom',
                    args: modal.params,
                };
                Ajax.call([request])[0].done(function(data) {
                    if (data === true) {
                        // Redirect to manage page.
                        window.location.reload();
                    } else {
                        Notification.addNotification({
                            message: String.get_string('delete_clsroom_failed', 'local_clsroom'),
                            type: 'error',
                        });
                    }
                }).fail(Notification.exception);
            });
        });

});
