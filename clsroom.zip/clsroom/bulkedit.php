<?php

/**
 * @package     local_clsroom
 * @author      iqraa
 * @license     http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

use local_clsroom\form\bulkedit;
use local_clsroom\manager;

require_once(__DIR__ . '/../../config.php');

require_login();
$context = context_system::instance();
require_capability('local/clsroom:manageclsrooms', $context);

$PAGE->set_url(new moodle_url('/local/clsroom/bulkedit.php'));
$PAGE->set_context(\context_system::instance());
$PAGE->set_title(get_string('bulk_edit', 'local_clsroom'));
$PAGE->set_heading(get_string('bulk_edit_clsrooms', 'local_clsroom'));

$clsroomid = optional_param('clsroomid', null, PARAM_INT);

// We want to display our form.
$mform = new bulkedit();
$manager = new manager();

if ($mform->is_cancelled()) {
    // Go back to manage.php page
    redirect($CFG->wwwroot . '/local/clsroom/manage.php', get_string('cancelled_form', 'local_clsroom'));
} else if ($fromform = $mform->get_data()) {
    $clsrooms = $fromform->clsrooms;
    $clsroomids = [];
    foreach ($clsrooms as $key => $enabled) {
        if ($enabled == true) {
            $clsroomids[] = substr($key, 9);
        }
    }

    if ($clsroomids) {
        if ($fromform->deleteall == true) {
            $manager->delete_clsrooms($clsroomids);
        } else {
            $manager->update_clsrooms($clsroomids, $fromform->clsroomtype);
        }
    }

    redirect($CFG->wwwroot . '/local/clsroom/manage.php', get_string('bulk_edit_successful', 'local_clsroom'));
}

echo $OUTPUT->header();
$mform->display();
echo $OUTPUT->footer();
