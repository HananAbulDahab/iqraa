<?php

/**
 * @package     local_clsroom
 * @author      iqraa
 * @license     http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

require_once(__DIR__ . '/../../config.php');

global $DB;

require_login();
$context = context_system::instance();
require_capability('local/clsroom:manageclsrooms', $context);

$PAGE->set_url(new moodle_url('/local/clsroom/manage.php'));
$PAGE->set_context(\context_system::instance());
$PAGE->set_title(get_string('manage_clsrooms', 'local_clsroom'));
$PAGE->set_heading(get_string('manage_clsrooms', 'local_clsroom'));
$PAGE->requires->js_call_amd('local_clsroom/confirm');
$PAGE->requires->css('/local/clsroom/styles.css');

$clsrooms = $DB->get_records('local_clsroom', null, 'id');

echo $OUTPUT->header();
$templatecontext = (object)[
    'clsrooms' => array_values($clsrooms),
    'editurl' => new moodle_url('/local/clsroom/edit.php'),
    'bulkediturl' => new moodle_url('/local/clsroom/bulkedit.php'),
];

echo $OUTPUT->render_from_template('local_clsroom/manage', $templatecontext);

echo $OUTPUT->footer();
