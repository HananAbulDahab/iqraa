<?php

/**
 * @package     local_message
 * @author      iqraa
 * @license     http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
//use local_clsroom\manager;

//function local_clsroom_before_footer() {
//    global $USER;

//    if (!get_config('local_clsroom', 'enabled')) {
//        return;
//    }

//    $manager = new manager();
//    $clsrooms = $manager->get_messages($USER->id);

//    foreach ($clsrooms as $clsroom) {
//        $type = \core\output\notification::NOTIFY_INFO;
//        if ($clsroom->clsroomtype === '0') {
//            $type = \core\output\notification::NOTIFY_WARNING;
//        }
//       $clsroom->mark_message_read($clsroom->id, $USER->id);
//    }
//}
