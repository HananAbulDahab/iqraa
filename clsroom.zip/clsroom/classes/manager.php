<?php


/**
 * @package     local_clsroom
 * @author      iqraa
 * @license     http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace local_clsroom;

use dml_exception;
use stdClass;

class manager {

    /** Insert the data into our database table.
     * @param string $clsroom_text
     * @param string $clsroom_type
     * @return bool true if successful
     */
    public function create_clsroom(string $clsroom_text, string $clsroom_type): bool
    {
        global $DB;
        $record_to_insert = new stdClass();
        $record_to_insert->clsroomtext = $clsroom_text;
        $record_to_insert->clsroomtype = $clsroom_type;
        try {
            return $DB->insert_record('local_clsroom', $record_to_insert, false);
        } catch (dml_exception $e) {
            return false;
        }
    }

    /** Gets all clsrooms >>>
     * @param int $userid the user that we are getting messages for
     * @return array of messages
     */
//    public function get_clsrooms(int $userid): array
//    {
//        global $DB;
//        $sql = "SELECT lm.id, lm.messagetext, lm.messagetype 
//            FROM {local_message} lm 
//            LEFT OUTER JOIN {local_message_read} lmr ON lm.id = lmr.messageid AND lmr.userid = :userid 
//            WHERE lmr.userid IS NULL";
//        $params = [
//            'userid' => $userid,
//        ];
//        try {
//            return $DB->get_records_sql($sql, $params);
//        } catch (dml_exception $e) {
//            // Log error here.
//            return [];
//        }
//    }

    /** Gets all clsrooms
     * @return array of clsrooms
     */
    public function get_all_clsrooms(): array {
        global $DB;
        return $DB->get_records('local_clsroom');
    }

    /** Mark that a clsroom was read by this user.
     * @param int $clsroom_id the message to mark as read
     * @param int $userid the user that we are marking message read
     * @return bool true if successful
     */
    //public function mark_message_read(int $message_id, int $userid): bool
    //{
    //    global $DB;
    //    $read_record = new stdClass();
    //    $read_record->messageid = $message_id;
    //    $read_record->userid = $userid;
    //    $read_record->timeread = time();
    //    try {
    //        return $DB->insert_record('local_message_read', $read_record, false);
    //    } catch (dml_exception $e) {
    //        return false;
    //    }
    // }

    /** Get a single clsroom from its id.
     * @param int $clsroomid the clsroom we're trying to get.
     * @return object|false clsroom data or false if not found.
     */
    public function get_clsroom(int $clsroomid)
    {
        global $DB;
        return $DB->get_record('local_clsroom', ['id' => $clsroomid]);
    }

    /** Update details for a single clsroom.
     * @param int $clsroomid the clsroom we're trying to get.
     * @param string $clsroom_text the new text for the clsroom.
     * @param string $clsroom_type the new type for the clsroom.
     * @return bool clsroom data or false if not found.
     */
    public function update_clsroom(int $clsroomid, string $clsroom_text, string $clsroom_type): bool
    {
        global $DB;
        $object = new stdClass();
        $object->id = $clsroomid;
        $object->clsroomtext = $clsroom_text;
        $object->clsroomtype = $clsroom_type;
        return $DB->update_record('local_clsroom', $object);
    }

    /** Update the type for an array of clsrooms.
     * @return bool clsroom data or false if not found.
     */
    public function update_clsrooms(array $clsroomids, $type): bool
    {
        global $DB;
        list($ids, $params) = $DB->get_in_or_equal($clsroomids);
        return $DB->set_field_select('local_clsroom', 'clsroomtype', $type, "id $ids", $params);
    }

    /** Delete a clsroom and all the read history.
     * @param $clsroomid
     * @return bool
     * @throws \dml_transaction_exception
     * @throws dml_exception
     */
    public function delete_clsroom($clsroomid)
    {
        global $DB;
        $transaction = $DB->start_delegated_transaction();
        $deletedClsroom = $DB->delete_records('local_clsroom', ['id' => $clsroomid]);
        //$deletedRead = $DB->delete_records('local_message_read', ['messageid' => $messageid]);
        if ($deletedClsroom ) {
            $DB->commit_delegated_transaction($transaction);
        }
        return true;
    }

    /** Delete all clsrooms by id.
     * @param $clsroomids
     * @return bool
     */
    public function delete_clsrooms($clsroomids)
    {
        global $DB;
        $transaction = $DB->start_delegated_transaction();
        list($ids, $params) = $DB->get_in_or_equal($clsroomids);
        $deletedClsrooms = $DB->delete_records_select('local_clsroom', "id $ids", $params);
        //$deletedReads = $DB->delete_records_select('local_clsroom_read', "clsroomid $ids", $params);
        if ($deletedClsrooms ) {
            $DB->commit_delegated_transaction($transaction);
        }
        return true;
    }
}
