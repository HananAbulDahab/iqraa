<?php


/**
 * @package     local_clsroom
 * @author      iqraa
 * @license     http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace local_clsroom\form;
use local_clsroom\manager;
use moodleform;

require_once("$CFG->libdir/formslib.php");

class bulkedit extends moodleform {
    public function definition() {
        $mform = $this->_form; // Don't forget the underscore!

        // Display the list of messages with a checkbox.
        $manager = new manager();
        $clsrooms = $manager->get_all_clsrooms();

        $clsroomgroup = [];
        foreach ($clsrooms as $clsroom) {
            $clsroomgroup[] = $mform->createElement('advcheckbox', 'clsroomid' . $clsroom->id, $clsroom->clsroomtext);
        }
        $mform->addGroup($clsroomgroup, 'clsrooms', get_string('choose_clsrooms', 'local_clsroom'), '<br>');

        $mform->addElement('static', 'todo', get_string('whattodo', 'local_message'));

        $choices = array();
        $choices['0'] = \core\output\notification::NOTIFY_WARNING;
        $choices['1'] = \core\output\notification::NOTIFY_SUCCESS;
        
        $mform->addElement('select', 'clsroomtype', get_string('clsroom_type', 'local_clsroom'), $choices);
        $mform->setDefault('clsroom', '1');

        $mform->addElement('advcheckbox', 'deleteall', get_string('delete_all_selected', 'local_clsroom'), get_string('yes'));

        $this->add_action_buttons();
    }
    //Custom validation should be added here
    function validation($data, $files) {
        return array();
    }
}
