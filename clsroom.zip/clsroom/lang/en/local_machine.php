<?php

/**
 * Strings for component 'local_clsroom', language 'en'
 *
 * @package   local_clsroom
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

$string['pluginname'] = 'Broadcast clsrooms';
$string['enter_clsroom'] = 'Please enter a clsroom';
$string['manage'] = 'Manage broadcast clsrooms';
$string['setting_enable'] = 'Enable';
$string['setting_enable_desc'] = 'Disable to stop any clsrooms from this plugin being displayed';
$string['clsroom_type'] = 'clsroom type';
$string['clsroom_text'] = 'clsroom text';
$string['clsroom:manageclsrooms'] = 'Manage clsrooms';
$string['cancelled_form'] = 'You cancelled the clsroom form';
$string['updated_form'] = 'You updated a clsroom with title ';
$string['created_form'] = 'You created a clsroom with title ';
$string['manage_clsrooms'] = 'Manage clsrooms';
$string['delete_clsroom'] = 'Delete clsroom';
$string['delete_clsroom_confirm'] = 'Are you sure you want to delete clsroom?';
$string['whattodo'] = 'What do you want to do with your selected clsrooms?';
$string['choose_clsrooms'] = 'Choose your clsrooms';
$string['delete_all_selected'] = 'Delete all selected?';
$string['bulk_edit'] = 'Bulk Edit';
$string['bulk_edit_clsrooms'] = 'Bulk edit your clsrooms';
$string['bulk_edit_successful'] = 'Bulk edit successful!';


